
1. GALLERY PAGE
- Kept same 3 images per row layout (350x250)
- Added names under each image 
- Made images clickable to go to services page
- Added srcset for responsive images
- Removed "click destination..." text

2. SERVICES PAGE
- Added 6 sections: bora, venice, taj, capetown, safari, egypt
- Each has 2-3 packages with price
- Book Now button -> goes to contact.html

3. CONTACT US PAGE
- Simple white cards design
- Fake SA numbers:
  Office: +27 11 234 5678
  WhatsApp: +27 82 555 1234
  Email: bookings@thompsonsholidays.co.za
  Address: 12 Rivonia Road, Sandton
- Added simple form (Name, Email, Phone, Message)

4. CSS
- Added flex for nav
- Added grid for packages and contact cards
- Added hover, focus, active effects
- Added media queries for mobile (768px and 480px)
- Used rem, em, %, vw
- Fixed gallery to be inline-block again

5. fixed HOME BUTTON ERROR
- Changed links from index to home
- Move folder out of OneDrive to Desktop to fix file not found

